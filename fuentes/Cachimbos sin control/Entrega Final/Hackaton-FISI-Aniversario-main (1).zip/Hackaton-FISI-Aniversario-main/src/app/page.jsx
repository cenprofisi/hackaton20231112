'use client'

import Navbar from '@/components/navbar/Navbar'
import { Panels } from '@/components/panels/Panels'


export default function Home() {
  return (
    <>
    <Navbar />
    <Panels />
    </>
  )
}
