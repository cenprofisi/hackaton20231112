import './Schedule.css'

export default function Schedule() {
    return (
        <div className="schedule">
            SCHEDULE
        </div>
    )
}
