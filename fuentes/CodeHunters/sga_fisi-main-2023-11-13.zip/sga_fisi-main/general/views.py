from django.shortcuts import render

# Create your views here.
def errorPage(request, exception=None):
    return render(request, 'general/error.html', {})