from django.db import models

# Create your models here.

# Revisado
class Semestre(models.Model):
    sem_iCodigo = models.AutoField(primary_key=True, editable=False)
    sem_vcCodigo = models.CharField(verbose_name="Código", blank=False, max_length=8)
    sem_cActivo = models.CharField(verbose_name="Activo", choices = (('S', 'Sí'),('N', 'No')), blank=False, default='N', max_length=1)
    def __str__(self):
        return self.sem_vcCodigo
    
    class Meta:
        verbose_name = "Semestre"
        verbose_name_plural = "Semestres"
        db_table = "semestre"
