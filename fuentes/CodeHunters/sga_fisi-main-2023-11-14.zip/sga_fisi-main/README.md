# SGA FISI
SGA FISI
## Equipo Code Hunters
- José Luis La Torre Romero
- Jorge Jesús Quispe Villaverde
## Herramientas
- Lenguaje de programación: Python 3.12
- Framework: Django 4.2.6
- Base de datos: MySQL Community Server 8.2.0
## Instalación y configuración
- Instalar MYSQL
- Instalar Python
- Crear un entorno virtual e instalar los requerimientos
- Dumpear la base de datos
- Arrancar el servidor django
